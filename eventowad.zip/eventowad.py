import cv2
import numpy as np
import pyautogui
import os
import time
import math


def distance(p1, p2):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

def click_center_of_screen():
    print("click center of screen")
    screen_width, screen_height = pyautogui.size()

    center_x = screen_width // 2
    center_y = screen_height // 2

    pyautogui.mouseDown(center_x, center_y)
    pyautogui.mouseUp(center_x, center_y)
    
def group_objects(points, filename):
    print("group_objects", filename, points)
    
    if len(points) < 2:
        return
    
    pos1, pos2 = points[0], points[1]

    if distance(pos1, pos2) >= 20:
        
        pyautogui.mouseDown(pos1)
        pyautogui.mouseUp(pos1)

        # Pequena pausa para evitar problemas de sincronização
        time.sleep(0.5)

        pyautogui.mouseDown(pos2)
        pyautogui.mouseUp(pos2)
        
        time.sleep(0.5)
    else:
        print("As posições estão muito próximas, não foi possível agrupar.")
 
def click_guarda(points, filename):
    print("click_guarda", filename, points)
    
    if len(points) < 1:
        return
    
    pos1 = points[0]
    pyautogui.moveTo(pos1)
    
    time.sleep(0.1)
    pyautogui.mouseDown(pos1)
    pyautogui.mouseUp(pos1)

    time.sleep(0.5)
    
def dividir_bau(points, filename):
    print("dividir_bau", filename, points)
    
    if len(points) < 1:
        return
    
    pos1 = points[0]

    pyautogui.keyDown('shift')
    time.sleep(0.2)
    pyautogui.mouseDown(pos1)
    time.sleep(0.2)
    pyautogui.mouseUp(pos1)
    time.sleep(0.2)
    pyautogui.keyUp('shift')
    time.sleep(0.2)
    pyautogui.press('1')
    time.sleep(0.2)
    pyautogui.press('enter')
    time.sleep(0.3)

def find_objects_on_screen(template):
    screen = pyautogui.screenshot()
    screen = cv2.cvtColor(np.array(screen), cv2.COLOR_RGB2BGR)

    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    threshold = 0.9  # Ajuste conforme necessário
    loc = np.where(result >= threshold)

    points = []
    template_height, template_width = template.shape[:2]
    for pt in zip(*loc[::-1]):
        center_pt = (pt[0] + template_width // 2, pt[1] + template_height // 2)
        if all(distance(center_pt, existing_pt) >= 20 for existing_pt in points):
            points.append(center_pt)

    return points

def find_objects_on_screen_marge7(template):
    screen = pyautogui.screenshot()
    screen = cv2.cvtColor(np.array(screen), cv2.COLOR_RGB2BGR)

    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    threshold = 0.7  # Ajuste conforme necessário
    loc = np.where(result >= threshold)

    points = []
    template_height, template_width = template.shape[:2]
    for pt in zip(*loc[::-1]):
        center_pt = (pt[0] + template_width // 2, pt[1] + template_height // 2)
        if all(distance(center_pt, existing_pt) >= 20 for existing_pt in points):
            points.append(center_pt)

    return points

def load_images_from_folder(folder):
    return [(filename, cv2.imread(os.path.join(folder, filename))) for filename in os.listdir(folder) if cv2.imread(os.path.join(folder, filename)) is not None]

def process_agrupar(images):
    for filename, template in images:
        item_points = find_objects_on_screen_marge7(template)
        while len(item_points) > 1:
            group_objects(item_points, filename)
            item_points = find_objects_on_screen_marge7(template)
            

def proccess_dividir(baus):

    for filename, template in baus:
        
        print("proccess_dividir", filename)
        bau_point = find_objects_on_screen(template)
        while len(bau_point) >= 1:
            dividir_bau(bau_point, filename)
            bau_point = find_objects_on_screen(template)
            break
    
def process_trocar(guardaImages):
    #for filename, template in guardaImages:
    #    guardaPoints = find_objects_on_screen(template)
    #    contador = 0
    #    while len(guardaPoints) > 1 and contador <= 1:
    #        click_guarda(guardaPoints, filename)
    #        item_points = find_objects_on_screen(template)
    #        contador += 1
    click_center_of_screen()
            
def main():
    itensAAgruparPath = 'c://Workspace/agrupador/itens'
    bauImagePath = 'c://Workspace/agrupador/bau'
    guardaImagesPath = 'c://Workspace/agrupador/guarda'

    
    agruparImages = load_images_from_folder(itensAAgruparPath)
    bauDividirImages = load_images_from_folder(bauImagePath)
    guardaTrocarImages = load_images_from_folder(guardaImagesPath)

    time.sleep(2)

    while True:
        
        proccess_dividir(bauDividirImages)
        time.sleep(0.5)
        process_trocar(guardaTrocarImages)
        time.sleep(1)
        process_agrupar(agruparImages)
        time.sleep(0.5)
        
        
        #pyautogui.press('g')
        #pyautogui.press('g')
        #pyautogui.press('insert')
        #pyautogui.keyDown('alt')
        #time.sleep(0.5)
        #pyautogui.press('tab')
        #time.sleep(0.5)
        #pyautogui.press('tab')
        #pyautogui.keyUp('alt')
        
        

        time.sleep(1)
        

if __name__ == "__main__":
    main()